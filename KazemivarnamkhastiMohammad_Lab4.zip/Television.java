/** 
 * The purpose of this class is to model a television.
 * @author MohammadAKazemi
 */
public class Television {
	// Attributes
	final private String MANUFACTURER;	// The brand of the TV
	final private int SCREEN_SIZE;	// The screen size of the TV
	private boolean powerOn;	// Boolean for whether the TV is on or off
	private int channel, volume;	// Integers for the channel and volume
	
	// Behaviors
	/**
	 * Constructor that takes a String and an integer to create a television
	 * The channel is set to 2, volume to 20, and powerOn to false (off).
	 * @param brand TV manufacturer
	 * @param size screen size of TV
	 */
	public Television(String brand, int size) {
		MANUFACTURER = brand;
		SCREEN_SIZE = size;
		powerOn = false;
		volume = 20;
		channel = 2;
	}
	/**
	 * Mutator method for channel
	 * @param station channel argument
	 */
	public void setChannel(int station) {
		channel = station;
	}
	/**
	 * Accessor method for channel
	 * @return channel
	 */
	public int getChannel() {
		return channel;
	}
	/**
	 * Switches the value of powerOn
	 */
	public void power() {
		powerOn = !powerOn;
	}
	/**
	 * Increments volume by one
	 */
	public void increaseVolume() {
		volume++;
	}
	/**
	 * Decreases volume by one
	 */
	public void decreaseVolume() {
		volume--;
	}
	/**
	 * Accessor method for volume
	 * @return volume
	 */
	public int getVolume() {
		return volume;
	}
	/**
	 * Accessor method for manufacturer
	 * @return MANUFACTURER
	 */
	public String getManufacturer() {
		return MANUFACTURER;
	}
	/**
	 * Accessor method for screen size
	 * @return SCREEN_SIZE
	 */
	public int getScreenSize() {
		return SCREEN_SIZE;
	}
}
